package com.tolet.toletapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToletappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToletappApplication.class, args);
	}

}
