package com.tolet.toletapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToletappApplicationTests {

	@Test
	void contextLoads() {
	}

}
